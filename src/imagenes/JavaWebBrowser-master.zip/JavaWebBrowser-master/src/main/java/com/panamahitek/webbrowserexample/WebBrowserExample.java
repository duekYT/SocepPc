package com.panamahitek.webbrowserexample;
public class WebBrowserExample {
    public static void main(String[] args) {
        JFrameWindow window = new JFrameWindow();
        window.setVisible(true);
    }
}
